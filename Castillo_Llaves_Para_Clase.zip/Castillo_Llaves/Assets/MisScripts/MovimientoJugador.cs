// Permite usar las herramientas de Unity: objetos, posiciones, teclas y componentes.
using UnityEngine;

// Unity añade un Character Controller si el objeto todavía no lo tiene.
[RequireComponent(typeof(CharacterController))]
// Define el componente que podremos colocar en un objeto de Unity.
public class MovimientoJugador : MonoBehaviour
{
    // Añade un título en el Inspector para organizar los ajustes.
    [Header("Movimiento")]
    // Rapidez al caminar, en unidades por segundo.
    public float velocidad = 6f;
    // Rapidez de giro del personaje, en grados por segundo.
    public float velocidadGiro = 360f;

    // Añade un título en el Inspector para organizar los ajustes.
    [Header("Salto")]
    // Velocidad vertical inicial del salto.
    public float fuerzaSalto = 7f;
    // Aceleración vertical: al ser negativa, tira del personaje hacia abajo.
    public float gravedad = -20f;

    // Añade un título en el Inspector para organizar los ajustes.
    [Header("Camara")]
    // Arrastra aquí la Main Camera.
    public Transform camara;
    // Cuánto gira la cámara al mover el ratón.
    public float sensibilidadRaton = 3f;
    // Separación entre la cámara y el punto que sigue.
    public float distanciaCamara = 5f;
    // Altura del punto al que mira la cámara respecto a la posición del jugador.
    public float alturaCamara = 2f;

    // Guarda el componente que mueve al jugador y comprueba el contacto con el suelo.
    private CharacterController controller;
    // Guarda la velocidad de subida o caída, que va cambiando con la gravedad.
    private float velocidadVertical;

    // Guarda el ángulo de la cámara hacia izquierda o derecha.
    private float rotacionHorizontal;
    // Guarda el ángulo de la cámara hacia arriba o abajo.
    private float rotacionVertical;

    // Unity ejecuta Start una vez antes de la primera actualización del componente habilitado: prepara los datos iniciales.
    void Start()
    {
        // Busca el Character Controller en este mismo objeto y guarda su referencia.
        controller = GetComponent<CharacterController>();

        // Si no hemos asignado cámara y existe una cámara activa con tag MainCamera, usa esa cámara.
        if (camara == null && Camera.main != null)
        {
            // Guarda el Transform de la cámara principal.
            camara = Camera.main.transform;
        }

        // Continúa solo si hay una cámara asignada.
        if (camara != null)
        {
            // Evitar que la cámara gire con el jugador.
            // Comprueba si la cámara está dentro del jugador en Hierarchy.
            if (camara.IsChildOf(transform))
            {
                // Saca la cámara del jugador para que su giro no se herede automáticamente.
                camara.SetParent(null);
            }

            // Toma el giro inicial de la cámara alrededor del eje Y.
            rotacionHorizontal = camara.eulerAngles.y;
            // Toma la inclinación inicial de la cámara alrededor del eje X.
            rotacionVertical = camara.eulerAngles.x;

            // Los ángulos pueden estar entre 0 y 360; convertimos los superiores a 180 a su equivalente negativo.
            if (rotacionVertical > 180f)
            {
                // Por ejemplo, 350 grados se convierten en -10 grados.
                rotacionVertical -= 360f;
            }

            // Limita la inclinación entre -30 y 70 grados para evitar giros excesivos.
            rotacionVertical = Mathf.Clamp(
                rotacionVertical, -30f, 70f
            );
        }
    }

    // Unity lo ejecuta cada fotograma: aquí se leen los controles y se mueve al jugador.
    void Update()
    {
        // Llama al método que lee el ratón y actualiza los ángulos.
        GirarCamara();
        // Llama al método que calcula caminar, saltar y caer.
        MoverJugador();
    }

    // Se ejecuta después de Update: coloca la cámara tras mover al personaje.
    void LateUpdate()
    {
        // Llama al método que coloca y orienta la cámara.
        ActualizarCamara();
    }

    // Agrupa las instrucciones para controlar la cámara con el botón derecho.
    void GirarCamara()
    {
        // Girar cámara solo con clic derecho.
        // Detecta el instante en que pulsamos el botón derecho: 1 identifica ese botón.
        if (Input.GetMouseButtonDown(1))
        {
            // Bloquea el cursor en el centro de la vista de juego para poder girar la cámara.
            Cursor.lockState = CursorLockMode.Locked;
            // Oculta la flecha del ratón mientras controlamos la cámara.
            Cursor.visible = false;
        }

        // Detecta el instante en que soltamos el botón derecho.
        if (Input.GetMouseButtonUp(1))
        {
            // Libera el cursor para poder moverlo normalmente.
            Cursor.lockState = CursorLockMode.None;
            // Vuelve a mostrar la flecha del ratón.
            Cursor.visible = true;
        }

        // Mientras mantengamos pulsado el botón derecho, permite girar la cámara.
        if (Input.GetMouseButton(1))
        {
            // Lee cuánto se ha movido el ratón horizontalmente.
            float mouseX = Input.GetAxis("Mouse X");
            // Lee cuánto se ha movido el ratón verticalmente.
            float mouseY = Input.GetAxis("Mouse Y");

            // Suma el movimiento horizontal multiplicado por la sensibilidad.
            rotacionHorizontal += mouseX * sensibilidadRaton;
            // Resta el movimiento vertical para controlar la inclinación de la cámara.
            rotacionVertical -= mouseY * sensibilidadRaton;

            // Limita la inclinación entre -30 y 70 grados para evitar giros excesivos.
            rotacionVertical = Mathf.Clamp(
                rotacionVertical, -30f, 70f
            );
        }
    }

    // Calcula la orientación y la posición de la cámara que sigue al jugador.
    void ActualizarCamara()
    {
        // Si falta la cámara, termina este método sin intentar utilizarla.
        if (camara == null) return;

        // Un Quaternion representa una rotación.
        Quaternion rotacion = Quaternion.Euler(
            rotacionVertical,
            rotacionHorizontal,
            0f
        );

        // Vector3 guarda tres valores (X, Y, Z).
        Vector3 objetivo = transform.position +
                           Vector3.up * alturaCamara;

        // Aplica la orientación calculada a la cámara.
        camara.rotation = rotacion;

        // Coloca la cámara detrás del objetivo.
        camara.position = objetivo -
                          rotacion * Vector3.forward *
                          distanciaCamara;
    }

    // Calcula la dirección del movimiento, el giro, el salto y la gravedad.
    void MoverJugador()
    {
        // Con los ejes predeterminados, lee A/D o flechas izquierda/derecha: valores entre -1 y 1.
        float horizontal = Input.GetAxis("Horizontal");
        // Con los ejes predeterminados, lee W/S o flechas arriba/abajo: valores entre -1 y 1.
        float vertical = Input.GetAxis("Vertical");

        // El operador ? : elige: si existe cámara, usa su dirección frontal; si no, la del jugador.
        Vector3 delante = camara != null
            ? camara.forward
            : transform.forward;

        // Elige la derecha de la cámara, o la del jugador si falta la cámara.
        Vector3 derecha = camara != null
            ? camara.right
            : transform.right;

        // Elimina la altura de la dirección frontal: mirar arriba no hace que el jugador vuele.
        delante.y = 0;
        // Mantiene también la dirección derecha sobre el plano horizontal.
        derecha.y = 0;

        // Convierte la dirección en un vector de longitud 1 si no es cero.
        delante.Normalize();
        // Normaliza la dirección derecha para que la inclinación no cambie la velocidad.
        derecha.Normalize();

        // Combina avance/retroceso e izquierda/derecha con las direcciones de la cámara.
        Vector3 direccion = delante * vertical +
                            derecha * horizontal;

        // magnitude mide la longitud: al pulsar dos direcciones, la diagonal puede ser más larga.
        if (direccion.magnitude > 1f)
        {
            // Limita la dirección a longitud 1 para no correr más rápido en diagonal.
            direccion.Normalize();
        }

        // El personaje gira hacia donde camina.
        // Gira el personaje solo cuando hay una dirección de movimiento suficientemente grande.
        if (direccion.magnitude > 0.1f)
        {
            // Prepara una rotación que mire hacia la dirección en que camina el personaje.
            Quaternion giroObjetivo =
                // Construye la orientación que apunta hacia esa dirección.
                Quaternion.LookRotation(direccion);

            // Acerca el giro actual al deseado de forma gradual, con el límite de grados indicado.
            transform.rotation = Quaternion.RotateTowards(
                transform.rotation,
                giroObjetivo,
                // Time.deltaTime es el tiempo entre fotogramas: hace que la rapidez de giro no dependa de los FPS.
                velocidadGiro * Time.deltaTime
            );
        }

        // Salto.
        // Comprueba si el Character Controller tocó el suelo durante su último movimiento.
        if (controller.isGrounded)
        {
            // Si estaba cayendo y ya toca el suelo, ajusta su velocidad vertical.
            if (velocidadVertical < 0)
            {
                // Mantiene una pequeña velocidad hacia abajo para ayudar a conservar el contacto con el suelo.
                velocidadVertical = -2f;
            }

            // Detecta la pulsación de espacio.
            if (Input.GetKeyDown(KeyCode.Space))
            {
                // Inicia el salto con una velocidad positiva, hacia arriba.
                velocidadVertical = fuerzaSalto;
            }
        }

        // Gravedad.
        // Añade el efecto de la gravedad con el tiempo: frena la subida y después acelera la caída.
        velocidadVertical += gravedad * Time.deltaTime;

        // Multiplica la dirección por la velocidad de caminar para obtener la velocidad horizontal.
        Vector3 movimientoFinal = direccion * velocidad;
        // Añade la velocidad vertical del salto o de la caída.
        movimientoFinal.y = velocidadVertical;

        // Move recibe un desplazamiento: velocidad por tiempo.
        controller.Move(movimientoFinal * Time.deltaTime);
    }

    // Unity lo llama al desactivar este componente, por ejemplo al ganar; devuelve el control normal del cursor.
    void OnDisable()
    {
        // Libera el cursor para poder moverlo normalmente.
        Cursor.lockState = CursorLockMode.None;
        // Vuelve a mostrar la flecha del ratón.
        Cursor.visible = true;
    }
}
