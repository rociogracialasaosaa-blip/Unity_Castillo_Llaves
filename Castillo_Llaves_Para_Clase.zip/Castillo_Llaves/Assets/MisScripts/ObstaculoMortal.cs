// Permite usar las herramientas de Unity: objetos, posiciones, teclas y componentes.
using UnityEngine;

// Define el componente que podremos colocar en un objeto de Unity.
public class ObstaculoMortal : MonoBehaviour
{
    // Unity lo llama cuando otro collider entra en esta zona trigger; other identifica al objeto que entra.
    void OnTriggerEnter(Collider other)
    {
        // Solo actúa si el objeto que entra tiene el tag Player; ignora los demás.
        if (other.CompareTag("Player"))
        {
            // Busca RespawnJugador en el jugador.
            other.GetComponent<RespawnJugador>().Reaparecer();
        }
    }
}
